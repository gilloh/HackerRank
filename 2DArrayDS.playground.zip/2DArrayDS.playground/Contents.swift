import Foundation

// Complete the hourglassSum function below.
func hourglassSum(arr: [[Int]]) -> Int {
  var maxSum = -9999
  var miniHourGlass = [[Int]]()
  
  for i in 0 ... arr.count-3 {
    for j in 0 ... 3 {
      miniHourGlass.append([arr[i][j], arr[i][j+1], arr[i][j+2]])
      miniHourGlass.append([0, arr[i+1][j+1], 0])
      miniHourGlass.append([arr[i+2][j], arr[i+2][j+1], arr[i+2][j+2]])
      maxSum = max(maxSum, getSumFromHourGlass(hour: miniHourGlass))
      print(miniHourGlass)
      miniHourGlass = [[Int]]()
    }
  }
  return maxSum
}

func getSumFromHourGlass(hour: [[Int]]) -> Int {
  var sum = 0
  
  for i in hour {
    for j in i {
      sum+=j
    }
  }
  print(sum)
  return sum
}

hourglassSum(arr: [[-1, -1, 0, -9, -2, -2],
                   [-2, -1, -6, -8, -2, -5],
                   [-1, -1, -1, -2, -3, -4]])


hourglassSum(arr: [[1, 1, 1, 0, 0, 0],
                   [0, 1, 0, 0, 0, 0],
                   [1, 1, 1, 0, 0, 0],
                   [0, 0, 2, 4, 4, 0],
                   [0, 0, 0, 2, 0, 0],
                   [0, 0, 1, 2, 4, 0]])
