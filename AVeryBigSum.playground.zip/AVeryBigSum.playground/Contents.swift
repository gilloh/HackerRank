func aVeryBigSum(ar: [Int]) -> Int {
  var sum = 0

  for case let i in ar as [Int] {
    sum+=i
  }
  return sum
}

aVeryBigSum(ar: [1000000001, 1000000002, 1000000003, 1000000004, 1000000005])
