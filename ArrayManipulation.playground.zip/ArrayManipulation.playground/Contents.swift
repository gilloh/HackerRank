import Foundation

// Complete the arrayManipulation function below.
//func arrayManipulation(n: Int, queries: [[Int]]) -> Int {
//  var array = [Int](repeating: 0, count: n)
//
////  print(array)
//
//  for i in queries {
//    let a = i[0] - 1
//    let b = i[1] - 1
//    let k = i[2]
//
//    array[a]+=k
//    array[b]-=k
//
////    let subArrayBefore = array[0..<i[0]-1]
////    let subArrayToApply = (array[i[0]-1...i[1]-1]).map { $0 + i[2] }
////    let subArrayAfter = array[i[1]..<array.count]
////
////    array = subArrayBefore + subArrayToApply + subArrayAfter
//
////    for j in i[0]-1...i[1]-1 {
////      array[j]+=i[2]
////    }
////    var subArray = Array(array[i[0]-1...i[1]-1])
////    subArray = subArray.map { $0 + i[2] }
////    array[i[0]-1...i[1]-1] = subArray.map { $0 + i[2] }
//  }
//
//  var sum: Double = 0
//  var maximum: Double = 0
//
//  for y in 0..<n {
//    sum+=Double(array[y])
//    maximum = max(sum, maximum)
//  }
//
//    print(array)
//
//  return Int(maximum)//array.max()!
//}

func arrayManipulation(n: Int, queries: [[Int]]) -> Int {
  
  var array = Array(repeating: 0, count: n+1)
  
  for query in queries {
    let a = query[0] - 1
    let b = query[1]
    let k = query[2]
    
    array[a] += k
    array[b] -= k
  }
  
  var largestValue = Int.min
  var sum = 0
  for n in array {
    sum += n
    largestValue = max(sum, largestValue)
  }
  
  return largestValue
}

arrayManipulation(n: 5, queries: [[1, 2, 100], [2, 5, 100], [3, 4, 100]]) // 200
