// Complete the reverseArray function below.
func reverseArray(a: [Int]) -> [Int] {
  return a.reversed()
}
