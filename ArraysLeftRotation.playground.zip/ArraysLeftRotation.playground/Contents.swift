func rotLeft(a: [Int], d: Int) -> [Int] {
  let offset = d % a.count
  return Array(a[offset..<a.count] + a[0..<offset])
}

rotLeft(a: [1,2,3,4], d: 2)

