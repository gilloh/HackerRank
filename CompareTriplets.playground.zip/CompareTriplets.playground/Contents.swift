import Foundation

// Complete the compareTriplets function below.
func compareTriplets(a: [Int], b: [Int]) -> [Int] {
  var alice = 0
  var bob = 0

  for i in a.indices {
    if a[i] > b[i] {
      alice+=1
    } else if a[i] < b[i]{
      bob+=1
    }
  }
  return [alice, bob]
}


compareTriplets(a: [1,2,3], b: [3,4,5])

