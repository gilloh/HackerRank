import Foundation

func countingValleys(n: Int, s: String) -> Int {
  var nValeys = 0
  var wasBelowSeaLevel = false
  var seaLevel = 0 {
    didSet {
      if seaLevel < 0 {
        wasBelowSeaLevel = true
      } else if seaLevel > 0 {
        wasBelowSeaLevel = false
      }
    }
  }

  for c in s {
    if c == "U" { seaLevel+=1 } else { seaLevel-=1 }
    if seaLevel >= 0 && wasBelowSeaLevel { nValeys+=1 }
  }
  return nValeys
}

countingValleys(n: 8, s: "UDDDUDUU")

// _/\      _
//    \    /
//     \/\/
