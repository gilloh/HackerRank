func diagonalDifference(arr: [[Int]]) -> Int {
  var diagonalOne = [Int]()
  var diagonalTwo = [Int]()

  for i in arr.indices {
    diagonalOne.append(arr[i][i])
    let back = arr.count - 1 - i
    diagonalTwo.append(arr[i][back])
  }

  return sumArray(a: diagonalOne, b: diagonalTwo)
}

func sumArray(a: [Int], b: [Int]) -> Int {
  var sumOne = 0
  var sumTwo = 0

  for i in a {
    sumOne+=i
  }

  for j in b {
    sumTwo+=j
  }

  return abs(sumOne - sumTwo)
}


diagonalDifference(arr: [[11, 2, 4],[4, 5, 6],[10, 8, -12]])



