import Foundation

// Complete the dynamicArray function below.
func dynamicArray(n: Int, queries: [[Int]]) {//} -> [Int] {
  var seqList = [[Int]](repeating: [], count: n)
  var finalArray = [Int]()
  var lastAnswer = 0
  
  for i in queries {
    
    switch i[0] {
    case 1:
      let seq = ((i[1] ^ lastAnswer) % n)
      seqList[seq].append(i[2])
    default:
      let seq = ((i[1] ^ lastAnswer) % n)
      lastAnswer = seqList[seq][i[2] % seqList[seq].count]
      print(lastAnswer)
      //finalArray.append(lastAnswer)
    }
  }
//  return finalArray
}

dynamicArray(n: 2, queries: [[1, 0, 5], [1, 1, 7], [1, 0, 3], [2, 1, 0], [2, 1, 1]])
