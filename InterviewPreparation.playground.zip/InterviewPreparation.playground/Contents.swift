// First Challenge - easy

// 1: Complete the findNumber function below.
func findNumber(arr: [Int], k: Int) -> String {
  for case let i in arr as [Int] {
    if i == k {
      return "YES"
    }
  }
  return "NO"
}

// 2: Complete the oddNumbers function below.
func oddNumbers(l: Int, r: Int) -> [Int] {
  var oddArray = [Int]()
  for i in l ... r {
    if isOdd(n: i) {
      oddArray.append(i)
    }
  }
  return oddArray
}

func isOdd(n: Int) -> Bool {
  return n%2 != 0
}

// 3: BubbleSort O(n) complexity
