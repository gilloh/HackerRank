// Complete the jumpingOnClouds function below.
func jumpingOnClouds(c: [Int]) -> Int {
  var minimumJumps = 0
  var i = 0

  while i < c.count {
    if i+1 == c.count - 1 || i+2 == c.count - 1 {
      minimumJumps+=1
      break
    } else {
      if c[i+2] == 1 {
        i+=1
      } else {
        i+=2
      }
      minimumJumps+=1
    }
  }
  return minimumJumps
}


jumpingOnClouds(c: [0, 0, 1, 0, 0, 1, 0])
jumpingOnClouds(c: [0, 0, 0, 0, 1, 0])
jumpingOnClouds(c: [0, 0, 0, 1, 0, 0])
