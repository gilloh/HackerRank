import Foundation

// Complete the minimumSwaps function below.
func minimumSwaps(arr: [Int]) -> Int {
  var minSwaps = 0
  var copyArr = arr

  for i in 0 ..< copyArr.count {
    for j in (0 ..< copyArr.count).reversed() {
      
    }
    print(copyArr[i])
    print(copyArr[i+1])

    copyArr.swapAt(i, i+1)

    print(copyArr)

//    if copyArr[i] == i {
//
//    }
  }



  return minSwaps
}

minimumSwaps(arr: [4, 3, 1, 2]) // 3
// 0, 2 -> [1, 3, 4, 2]
// 1, 2 -> [1, 4, 3, 2]
// 1, 3 -> [1, 2, 3, 4]

// 0, 2 -> [1, 3, 4, 2]
// 1, 2 -> [1, 2, 4, 3]
// 1, 3 -> [1, 2, 3, 4]

minimumSwaps(arr: [2, 3, 4, 1, 5]) // 3
// 0,
//


minimumSwaps(arr: [1, 3, 5, 2, 4, 6, 7]) // 3
