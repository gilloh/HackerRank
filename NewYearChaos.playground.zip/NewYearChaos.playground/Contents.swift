import Foundation

import Foundation

// Complete the minimumBribes function below.
func minimumBribesOne(q: [Int]) -> Void {
  var minBribes = 0
  var isChaotic = false
  
  var sortedArray = q
  var sortedAboveIndex = q.count
  
  for i in q.indices {
    if q[i] > i+3 {
      isChaotic = true
    }
  }
  
  repeat {
    var lastSwapIndex = 0
    
    for i in 1 ..< sortedAboveIndex {
      if sortedArray[i - 1] > sortedArray[i] {
        (sortedArray[i], sortedArray[i-1]) = (sortedArray[i-1], sortedArray[i])
        lastSwapIndex = i
        minBribes += 1
      }
    }
    
    sortedAboveIndex = lastSwapIndex
    
  } while (sortedAboveIndex != 0)
  
  isChaotic ? print("Too chaotic") : print(minBribes)
}



func minimumBribes(q: [Int]) -> Void {
  var minB = 0
  
  for()
  for i in (-1 ... q.count-1).reversed() {
    if q[i] - (i + 1) > 2 {
      print("Too chaotic")
      return
    }
    for j in [0, q[i] - 2].max()! ..< i {
      if q[j] > q[i] {
        minB+=1
      }
    }
  }
  print(minB)
}

//def minimumBribes(q):
//bribes = 0
//for i in range(len(q)-1,-1,-1):
//if q[i] - (i + 1) > 2:
//print('Too chaotic')
//return
//for j in range(max(0, q[i] - 2),i):
//if q[j] > q[i]:
//bribes+=1
//print(bribes)

minimumBribes(q: [2, 1, 5, 3, 4]) // 3
minimumBribes(q: [2, 1, 5, 4, 3]) // 4
minimumBribes(q: [2, 5, 1, 3, 4]) // "Too chaotic"
minimumBribes(q: [1, 2, 5, 3, 7, 8, 6, 4]) // 7
minimumBribes(q: [1, 2, 5, 3, 7, 8, 6, 9, 4]) // 8
