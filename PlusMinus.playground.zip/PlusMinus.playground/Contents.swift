// Complete the plusMinus function below.
func plusMinus(arr: [Int]) -> Void {
  var plus = [Float]()
  var minus = [Float]()
  var zeros = [Float]()

  for i in arr {
    if i < 0 {
      minus.append(Float(i))
    } else if i > 0 {
      plus.append(Float(i))
    } else if i == 0 {
      zeros.append(Float(i))
    }
  }
  print(Float(plus.count)/Float(arr.count))
  print(Float(minus.count)/Float(arr.count))
  print(Float(zeros.count)/Float(arr.count))
}

plusMinus(arr: [-4, 3, -9, 0, 4, 1])
