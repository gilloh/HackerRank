import Foundation

// Complete the repeatedString function below.
func repeatedString(s: String, n: Int) -> Int {
  var count = 0

  for i in s { count += i == "a" ? 1 : 0 }

  func getTheRestOfAs(_ rest: Int) -> Int {
    var count = 0
    var iteration = 0
    for i in s {
      if iteration < rest {
        count += i == "a" ? 1 : 0
        iteration += 1
      } else { break }
    }
    return count
  }

  if count == s.count {
    return n
  } else {
    count = (n/s.count) * count + getTheRestOfAs(n % s.count)
  }
  return count
}

//repeatedString(s:"aba", n: 10) // abaabaabaa
//repeatedString(s:"abcac", n: 10) // abcac
//repeatedString(s:"a", n: 10000) //
repeatedString(s: "epsxyyflvrrrxzvnoenvpegvuonodjoxfwdmcvwctmekpsnamchznsoxaklzjgrqruyzavshfbmuhdwwmpbkwcuomqhiyvuztwvq", n: 549382313570) // 16481469408
repeatedString(s: "gfcaaaecbg", n: 547602) // 164280
