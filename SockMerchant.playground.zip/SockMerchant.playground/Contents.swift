import Foundation

// Complete the sockMerchant function below.
func sockMerchant(n: Int, ar: [Int]) -> Int {
  var counter = 0
  var tempArray = ar
  
  while tempArray.count > 0 {
    let i = tempArray.first
    tempArray.removeFirst()
    
    for index in tempArray.indices {
      if i == tempArray[index] {
        counter+=1
        tempArray.remove(at: index)
        break
      }
    }
  }
  return counter
}

sockMerchant(n: 9, ar: [10, 20, 20, 10, 10, 30, 50, 10, 20])
