import Foundation

// Complete the matchingStrings function below.
func matchingStrings(strings: [String], queries: [String]) -> [Int] {
  var occurArray = [Int]()
  
  for i in queries {
    let copy = strings.filter { i == $0 }
    occurArray.append(copy.count)
  }

  return occurArray
}

matchingStrings(strings: ["aba", "baba", "aba", "xzxb"], queries: ["aba", "xzxb", "ab"])

