import Foundation

// Complete the staircase function below.
func staircase(n: Int) -> Void {
  
  var final = [String](repeating: " ", count: n)
  var counter = n
  
  while counter > 0 {
    for i in (0 ..< n).reversed() {
      if counter <= i+1 {
        final[i] = "#"
      }
    }
    print(final.joined())
    counter-=1
    final = [String](repeating: " ", count: n)
  }
}

staircase(n: 6)
